package com.example.areal.Models;

import java.util.ArrayList;

public class Root{
    public ArrayList<Recipe> recipes;
}