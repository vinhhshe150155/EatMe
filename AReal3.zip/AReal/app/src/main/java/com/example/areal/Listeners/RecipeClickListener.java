package com.example.areal.Listeners;

public interface RecipeClickListener {
    void onRecipeClicked(String id);

}
