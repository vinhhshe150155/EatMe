package com.example.areal.Models;

public class Bad{
    public String name;
    public String amount;
    public boolean indented;
    public double percentOfDailyNeeds;
}
