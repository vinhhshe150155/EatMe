package com.example.areal.Models;

public class Length{
    public int number;
    public String unit;
}