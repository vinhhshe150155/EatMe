package com.example.areal.Models;

public class Good{
    public String amount;
    public boolean indented;
    public double percentOfDailyNeeds;
    public String name;
}
