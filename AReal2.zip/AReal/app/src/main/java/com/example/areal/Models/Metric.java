package com.example.areal.Models;

public class Metric{
    public double amount;
    public String unitShort;
    public String unitLong;
}